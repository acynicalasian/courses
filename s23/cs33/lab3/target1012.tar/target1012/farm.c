/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_130()
{
    return 3251079496U;
}

void setval_286(unsigned *p)
{
    *p = 3347662900U;
}

unsigned getval_481()
{
    return 3284633928U;
}

unsigned addval_460(unsigned x)
{
    return x + 1354979525U;
}

void setval_293(unsigned *p)
{
    *p = 2425393272U;
}

void setval_232(unsigned *p)
{
    *p = 3281293400U;
}

unsigned getval_487()
{
    return 3351742792U;
}

void setval_229(unsigned *p)
{
    *p = 1492198028U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_367()
{
    return 3281047947U;
}

unsigned addval_497(unsigned x)
{
    return x + 3247492745U;
}

unsigned addval_390(unsigned x)
{
    return x + 1438896525U;
}

unsigned getval_323()
{
    return 3767093616U;
}

unsigned getval_320()
{
    return 3678981769U;
}

void setval_470(unsigned *p)
{
    *p = 2126758537U;
}

unsigned addval_247(unsigned x)
{
    return x + 3372797577U;
}

unsigned addval_387(unsigned x)
{
    return x + 2425668233U;
}

unsigned addval_159(unsigned x)
{
    return x + 3232023177U;
}

unsigned getval_101()
{
    return 3286272456U;
}

void setval_306(unsigned *p)
{
    *p = 3285288999U;
}

unsigned getval_127()
{
    return 3523789453U;
}

unsigned addval_278(unsigned x)
{
    return x + 3525365384U;
}

unsigned addval_144(unsigned x)
{
    return x + 3526413961U;
}

void setval_275(unsigned *p)
{
    *p = 2463205886U;
}

unsigned addval_176(unsigned x)
{
    return x + 2425409929U;
}

unsigned addval_482(unsigned x)
{
    return x + 2430634248U;
}

unsigned getval_222()
{
    return 3526935241U;
}

unsigned addval_282(unsigned x)
{
    return x + 3680555401U;
}

unsigned getval_299()
{
    return 2428668370U;
}

unsigned addval_451(unsigned x)
{
    return x + 1489227401U;
}

void setval_429(unsigned *p)
{
    *p = 3281047945U;
}

unsigned addval_136(unsigned x)
{
    return x + 3677933257U;
}

unsigned getval_350()
{
    return 3353381192U;
}

void setval_364(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_283()
{
    return 2429655381U;
}

void setval_147(unsigned *p)
{
    *p = 3380920985U;
}

void setval_430(unsigned *p)
{
    *p = 2464188744U;
}

void setval_331(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_449()
{
    return 2496563487U;
}

unsigned addval_241(unsigned x)
{
    return x + 3286272328U;
}

void setval_279(unsigned *p)
{
    *p = 3223896713U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
